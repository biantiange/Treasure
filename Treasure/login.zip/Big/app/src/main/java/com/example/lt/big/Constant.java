package com.example.lt.big;

public class Constant {
    public static final String BASE_IP ="http://10.7.88.138:8080/big/";
}
